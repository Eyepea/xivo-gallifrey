# Defaults for chan-sccp-b initscript
# sourced by /etc/init.d/chan-sccp-b
# installed at /etc/default/chan-sccp-b by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
